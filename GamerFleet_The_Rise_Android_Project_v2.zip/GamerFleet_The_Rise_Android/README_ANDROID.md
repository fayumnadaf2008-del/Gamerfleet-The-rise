# GAMERFLEET: THE RISE — Android project

Unofficial fan-made prototype; not affiliated with or endorsed by GamerFleet.

## Build APK using Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Let Gradle sync complete.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using GitHub Actions (no Android Studio on your computer)
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (including `.github`).
3. Open the repository's **Actions** tab.
4. Run **Build Android APK** (or push to `main` / `master`).
5. When the workflow finishes, open its run and download the artifact named `GamerFleet-The-Rise-debug-apk`.
6. Extract the artifact and install `app-debug.apk` on your Android phone. If Android asks, allow installs from the app you used to open the APK.

## Controls
- On-screen D-pad: move
- Hold RUN: run
- INTERACT: talk to the shopkeeper near the gold marker
- Drag the 3D world: rotate camera
- INDIA MAP: show the stylized route overview

## Notes
- The app opens in landscape orientation.
- Internet is required because Three.js is loaded from jsDelivr CDN.
- This is an early playable prototype. The India map is a stylized foundation, not a fully explorable national road network.
- A debug APK is for testing. A release APK should be signed before public distribution.
