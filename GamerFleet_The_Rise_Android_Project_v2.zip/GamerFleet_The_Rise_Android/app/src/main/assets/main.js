import * as THREE from 'three';

const mount = document.getElementById('game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9db9c4);
scene.fog = new THREE.Fog(0x9db9c4, 65, 260);
const camera = new THREE.PerspectiveCamera(65, innerWidth/innerHeight, .1, 700);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xcfe5f2,0x59614a,2.0));
const sun = new THREE.DirectionalLight(0xffe1b0,2.5);
sun.position.set(-55,90,35); sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-100;sun.shadow.camera.right=100;sun.shadow.camera.top=100;sun.shadow.camera.bottom=-100;
scene.add(sun);

const mats = {
 grass:new THREE.MeshStandardMaterial({color:0x657d50,roughness:1}),
 road:new THREE.MeshStandardMaterial({color:0x343b3b,roughness:.95}),
 concrete:new THREE.MeshStandardMaterial({color:0x8d9188,roughness:1}),
 white:new THREE.MeshStandardMaterial({color:0xe8e3d1}),
 wall:new THREE.MeshStandardMaterial({color:0xb6a58b,roughness:.95}),
 wall2:new THREE.MeshStandardMaterial({color:0xc5c1ae,roughness:1}),
 roof:new THREE.MeshStandardMaterial({color:0x66594b}),
 glass:new THREE.MeshStandardMaterial({color:0x426a78,metalness:.25,roughness:.25}),
 dark:new THREE.MeshStandardMaterial({color:0x252b2c,roughness:.7}),
 green:new THREE.MeshStandardMaterial({color:0x345c3d,roughness:1}),
 gold:new THREE.MeshStandardMaterial({color:0xe7b84e,emissive:0x6b3900,emissiveIntensity:.5})
};
const ground = new THREE.Mesh(new THREE.PlaneGeometry(500,500),mats.grass);
ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);

function box(x,y,z,sx,sy,sz,mat, parent=scene){
 const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
}
function road(x,z,w,d,rot=0){
 const r=new THREE.Mesh(new THREE.PlaneGeometry(w,d),mats.road);r.rotation.x=-Math.PI/2;r.rotation.z=rot;r.position.set(x,.025,z);r.receiveShadow=true;scene.add(r);
 // broken centre markings
 const count=Math.max(2,Math.floor(d/8));
 for(let i=0;i<count;i++){const mark=box(x, .045, z-d/2+(i+.5)*d/count, .16,.025,Math.min(2,d/count*.45),mats.white); if(rot)mark.rotation.y=rot;}
}
road(0,0,15,250); road(0,0,250,14,Math.PI/2);
road(-55,-42,90,9,Math.PI/4); road(58,54,90,9,-Math.PI/4);

// Distant Himalayan ridge
for(let i=0;i<18;i++){
 const h=25+Math.random()*38, x=-190+i*22;
 const mountain=new THREE.Mesh(new THREE.ConeGeometry(18+Math.random()*13,h,5),new THREE.MeshStandardMaterial({color:i%3===0?0x71877c:0x879b91,roughness:1}));
 mountain.position.set(x,h*.48,-185-Math.random()*25);mountain.rotation.y=Math.random();mountain.castShadow=true;scene.add(mountain);
 const snow=new THREE.Mesh(new THREE.ConeGeometry(7,h*.24,5),new THREE.MeshStandardMaterial({color:0xd7e0dd,roughness:1}));
 snow.position.set(x,h*.89,mountain.position.z);scene.add(snow);
}

// Trees
function tree(x,z,s=1){
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25*s,.38*s,3*s,7),new THREE.MeshStandardMaterial({color:0x5a4430}));
 trunk.position.set(x,1.5*s,z);trunk.castShadow=true;scene.add(trunk);
 for(let j=0;j<3;j++){const crown=new THREE.Mesh(new THREE.ConeGeometry((2.1-j*.35)*s,3.3*s,7),new THREE.MeshStandardMaterial({color:j===0?0x31583d:0x3f7049,roughness:1}));crown.position.set(x,(3.2+j*1.15)*s,z);crown.castShadow=true;scene.add(crown);}
}
for(let i=0;i<95;i++){let x=(Math.random()-.5)*260,z=(Math.random()-.5)*250;if(Math.abs(x)<13||Math.abs(z)<13)continue;tree(x,z,.7+Math.random()*.65);}

// Town buildings
function building(x,z,w,d,h,mat, shop=false){
 box(x,h/2,z,w,h,d,mat);
 box(x,h+.18,z,w+.3,.35,d+.3,mats.roof);
 // front windows facing camera/road
 for(let y=3;y<h-1;y+=4){for(let xx=-w/2+1.3;xx<w/2-1;xx+=3.2){box(x+xx,y,z+d/2+.012,1.25,1.5,.06,mats.glass);}}
 if(shop){box(x,h*.42,z+d/2+.13,w*.72,.8,.15,mats.dark);box(x,h*.42,z+d/2+.23,w*.66,.52,.04,mats.gold);}
}
const buildingMats=[mats.wall,mats.wall2,new THREE.MeshStandardMaterial({color:0xb99a79}),new THREE.MeshStandardMaterial({color:0x9bafa4})];
for(let side of [-1,1]){
 for(let i=0;i<10;i++){
  const z=-90+i*19;
  if(Math.abs(z)<18)continue;
  building(side*(17+Math.random()*5),z,10+Math.random()*5,10+Math.random()*5,8+Math.random()*17,buildingMats[i%4],i===4);
 }
 for(let i=0;i<7;i++){
  const x=-100+i*30;if(Math.abs(x)<20)continue;
  building(x,side*(18+Math.random()*5),12,11,9+Math.random()*12,buildingMats[(i+1)%4],false);
 }
}
// Landmark computer shop, start marker
building(-25,-18,15,11,9,mats.wall2,true);
const sign=box(-25,5.3,-12.35,10,1.2,.18,mats.gold);
const signText=makeLabel('COMPUTER HOUSE',0x241a0c);signText.position.set(-25,5.3,-12.22);scene.add(signText);
function makeLabel(text,color=0xffffff){
 const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#ffffff';ctx.font='bold 54px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,256,64);
 const tex=new THREE.CanvasTexture(c);const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,color}));sprite.scale.set(10,2.5,1);return sprite;
}

// Player: simple stylized third-person avatar
const player=new THREE.Group();scene.add(player);player.position.set(0,0,34);
const skin=new THREE.MeshStandardMaterial({color:0xc58d69}), shirt=new THREE.MeshStandardMaterial({color:0x263d59}), pants=new THREE.MeshStandardMaterial({color:0x242b36});
const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.85,5,8),shirt);torso.position.y=1.45;torso.castShadow=true;player.add(torso);
const head=new THREE.Mesh(new THREE.SphereGeometry(.34,16,12),skin);head.position.y=2.35;head.castShadow=true;player.add(head);
const hair=new THREE.Mesh(new THREE.SphereGeometry(.35,12,8,0,Math.PI*2,0,Math.PI*.52),mats.dark);hair.position.y=2.48;player.add(hair);
for(let s of [-1,1]){const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.19,.75,4,7),pants);leg.position.set(s*.23,.55,0);player.add(leg);const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.14,.65,4,7),skin);arm.position.set(s*.59,1.45,0);arm.rotation.z=s*.13;player.add(arm);}

const marker=new THREE.Group();scene.add(marker);marker.position.set(-25,0,-8);
const ring=new THREE.Mesh(new THREE.TorusGeometry(2.3,.16,8,36),mats.gold);ring.rotation.x=Math.PI/2;ring.position.y=.15;marker.add(ring);
const beam=new THREE.Mesh(new THREE.CylinderGeometry(.12,.8,5,16,1,true),new THREE.MeshBasicMaterial({color:0xffc54d,transparent:true,opacity:.18,side:THREE.DoubleSide}));beam.position.y=2.5;marker.add(beam);
const pin=new THREE.Mesh(new THREE.ConeGeometry(.55,1.2,12),mats.gold);pin.position.y=5.5;marker.add(pin);

// Simple parked car
const car=new THREE.Group();scene.add(car);car.position.set(12,0,24);car.rotation.y=-Math.PI/2;
box(0,.75,0,2.2,.8,4.2,new THREE.MeshStandardMaterial({color:0x9c3430}),car);
box(0,1.42,-.25,1.8,.85,2.15,mats.glass,car);
for(let x of [-1.05,1.05])for(let z of [-1.35,1.35]){const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.25,16),mats.dark);wheel.rotation.z=Math.PI/2;wheel.position.set(x,.48,z);car.add(wheel);}

// Camera and controls
const keys={};let yaw=0,pitch=.28,mode='story',dialogueStep=0,missionDone=false,toastTimer=0;
let isDragging=false,lastX=0,lastY=0,runTouch=false;
const isMobile=matchMedia('(pointer:coarse)').matches;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==='m')toggleMap();if(e.key.toLowerCase()==='e')interact();if(e.key.toLowerCase()==='f')toggleMode();});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
renderer.domElement.addEventListener('pointerdown',e=>{
 if(e.pointerType==='mouse'){isDragging=true;lastX=e.clientX;lastY=e.clientY;}
 else if(e.pointerType==='touch'){isDragging=true;lastX=e.clientX;lastY=e.clientY;}
});
renderer.domElement.addEventListener('touchstart',e=>{e.preventDefault();},{passive:false});
addEventListener('pointerup',()=>isDragging=false);
addEventListener('pointermove',e=>{if(isDragging){yaw-=(e.clientX-lastX)*.004;pitch=clamp(pitch+(e.clientY-lastY)*.003,-.05,.85);lastX=e.clientX;lastY=e.clientY;}});
function bindHold(btn,key){const el=document.querySelector(btn);if(!el)return;el.addEventListener('pointerdown',e=>{e.preventDefault();keys[key]=true;});['pointerup','pointerleave','pointercancel'].forEach(ev=>el.addEventListener(ev,()=>keys[key]=false));}
document.querySelectorAll('[data-key]').forEach(el=>{const map={forward:'w',back:'s',left:'a',right:'d'};const k=map[el.dataset.key];el.addEventListener('pointerdown',e=>{e.preventDefault();keys[k]=true;});['pointerup','pointerleave','pointercancel'].forEach(ev=>el.addEventListener(ev,()=>keys[k]=false));});
document.getElementById('runBtn').addEventListener('pointerdown',()=>runTouch=true);['pointerup','pointerleave'].forEach(ev=>document.getElementById('runBtn').addEventListener(ev,()=>runTouch=false));
document.getElementById('interactBtn').onclick=interact;
document.getElementById('mapToggle').onclick=toggleMap;document.getElementById('closeMap').onclick=toggleMap;
function toggleMap(){document.getElementById('mapPanel').classList.toggle('hidden');}
function toggleMode(){mode=mode==='story'?'free':'story';document.getElementById('modeLabel').textContent=mode==='story'?'STORY MODE':'FREE ROAM';toast(mode==='story'?'Story mode enabled':'Free roam enabled');}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.style.opacity=1;toastTimer=2.2;}
const dlg=document.getElementById('dialogue');
function interact(){
 if(!dlg.classList.contains('hidden')){advanceDialogue();return;}
 const dist=player.position.distanceTo(new THREE.Vector3(-25,0,-8));
 if(dist<9&&!missionDone){dlg.classList.remove('hidden');dialogueStep=0;setDialogue();return;}
 toast(dist<9?'The shop is ready. Press E to talk.':'Nothing to interact with nearby.');
}
const lines=[
 ['SHOPKEEPER','Welcome! Looking for something, young man?'],
 ['YOU','I want to build a gaming setup. I have big plans, but I need to start somewhere.'],
 ['SHOPKEEPER','Then start with what you can afford. Learn, create, and keep improving. A journey is built one step at a time.'],
 ['MISSION COMPLETE','You found your first lead. Your creator journey begins now.']
];
function setDialogue(){document.getElementById('dialogueName').textContent=lines[dialogueStep][0];document.getElementById('dialogueText').textContent=lines[dialogueStep][1];document.getElementById('dialogueNext').textContent=dialogueStep===lines.length-1?'FINISH':'CONTINUE';}
function advanceDialogue(){dialogueStep++;if(dialogueStep>=lines.length){dlg.classList.add('hidden');missionDone=true;document.getElementById('missionTitle').textContent='FIRST STEP TAKEN';document.getElementById('missionText').textContent='Explore Haldwani. Your next chapter will unlock in a future update.';document.getElementById('missionStatus').textContent='COMPLETED · FREE ROAM UNLOCKED';document.getElementById('progressBar').style.width='100%';marker.visible=false;toast('Mission completed! Free roam is yours.');return;}setDialogue();}
document.getElementById('dialogueNext').onclick=advanceDialogue;

const clock=new THREE.Clock();
const camTarget=new THREE.Vector3();
function update(dt){
 let forward=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0);
 let side=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0);
 const moving=forward!==0||side!==0;
 if(moving){
  const speed=(keys.shift||runTouch)?13:7;
  const dir=new THREE.Vector3(side,0,-forward).normalize();
  dir.applyAxisAngle(new THREE.Vector3(0,1,0),yaw);
  player.position.addScaledVector(dir,speed*dt);
  player.position.x=clamp(player.position.x,-220,220);player.position.z=clamp(player.position.z,-220,220);
  player.rotation.y=Math.atan2(dir.x,dir.z);
 }
 const desired=new THREE.Vector3(player.position.x+Math.sin(yaw)*10,player.position.y+5+pitch*7,player.position.z+Math.cos(yaw)*10);
 camera.position.lerp(desired,1-Math.pow(.001,dt));camTarget.set(player.position.x,1.5,player.position.z);camera.lookAt(camTarget);
 marker.rotation.y+=dt*.8;beam.material.opacity=.13+Math.sin(performance.now()*.003)*.06;
 if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)document.getElementById('toast').style.opacity=0;}
 document.getElementById('speedLabel').textContent=moving?((keys.shift||runTouch)?'RUNNING':'WALKING'):'ON FOOT';
 if(!missionDone){const dist=player.position.distanceTo(new THREE.Vector3(-25,0,-8));document.getElementById('progressBar').style.width=(Math.max(8,Math.min(90,100-dist*4)))+'%';}
}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);update(dt);renderer.render(scene,camera);}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
if(isMobile)document.getElementById('desktopHelp').style.display='none';
toast('Welcome to Haldwani. Find the gold marker.');
